
public class Item 
{
	public String name, update; 
	public double current;
	public Item(String name, String update, double current) 
	{
		this.name = name;
		this.update = update;
		this.current = current;
	}
}