
public class Metal extends Item
{
	public Metal(String name, String update, double current) 
	{
		super(name, update, current);
		
	}
}